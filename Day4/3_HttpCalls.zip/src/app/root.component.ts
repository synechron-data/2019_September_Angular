import { Component, OnInit } from '@angular/core';
import { Post } from './models/post.model';
import { DataService } from './services/data.service';

@Component({
    selector: 'root',
    templateUrl: 'root.component.html',
    providers: [DataService]
})

export class RootComponent implements OnInit {
    posts: Array<Post>;
    message: string;

    constructor(private dService: DataService) {
        this.message = "Loading Data, please wait....";
    }

    ngOnInit() {
        // this.dService.getPosts().subscribe((resData) => {
        //     this.posts = resData;
        //     this.message = "";
        // }, (err: HttpErrorResponse) => {
        //     this.message = err.message;
        // });

        this.dService.getPosts().subscribe((resData) => {
            this.posts = resData;
            this.message = "";
        }, (err: string) => {
            this.message = err;
        });
    }
}

// import { Component, OnInit } from '@angular/core';
// import { Post } from './models/post.model';
// import { HttpClient, HttpErrorResponse } from "@angular/common/http";

// @Component({
//     selector: 'root',
//     templateUrl: 'root.component.html'
// })

// export class RootComponent implements OnInit {
//     posts: Array<Post>;
//     url: string;
//     message: string;

//     constructor(private httpClient: HttpClient) {
//         this.url = "https://jsonplaceholder.typicode.com/posts";
//         this.message = "Loading Data, please wait....";
//     }

//     ngOnInit() {
//         this.httpClient.get<Array<Post>>(this.url).subscribe((resData) => {
//             this.posts = resData;
//             this.message = "";
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//         });
//     }
// }