import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { Observable, Observer, Subject, Subscription } from 'rxjs';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Promises & Observables</h1>
            </div>

            <async-promise></async-promise>
            <hr/>
            <async-observable></async-observable>
        </div>
    `
})

export class RootComponent implements OnInit, AfterViewInit, OnDestroy {
    observable: Observable<number>;
    subject: Subject<number>;
    sub1: Subscription;
    sub2: Subscription;

    constructor() {
    }

    ngOnInit() {
        // this.observable = Observable.create((ob: Observer<number>) => {
        //     setInterval(function () {
        //         // console.log("Inside Observable....");
        //         ob.next(Math.random());
        //     }, 2000);
        // });

        // this.observable.subscribe((data) => {
        //     console.log("Observer 1 Output - ", data);
        // });

        // this.observable.subscribe((data) => {
        //     console.log("Observer 2 Output - ", data);
        // });

        this.subject = new Subject<number>();

        setInterval(() => {
            this.subject.next(Math.random());
        }, 2000);

        this.sub1 = this.subject.subscribe((data) => {
            console.log("S1 Output - ", data);
        });

        this.sub2 =this.subject.subscribe((data) => {
            console.log("S2 Output - ", data);
            this.sub2.unsubscribe();
        });

        // this.getPromise().then((data) => {
        //     console.log("Promise Output - ", data);
        // });
    }

    ngOnDestroy(): void {
        this.sub1.unsubscribe();
        this.sub2.unsubscribe();
    }

    ngAfterViewInit(): void {

    }

    getPromise(): Promise<number> {
        return new Promise((resolve, reject) => {
            setInterval(function () {
                resolve(Math.random());
            }, 2000);
        });
    }
}