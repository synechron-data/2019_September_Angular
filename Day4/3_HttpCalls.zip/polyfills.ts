// Should Condition Based
import 'core-js/es';
import 'core-js/proposals/reflect-metadata';

// Always needed
import 'zone.js/dist/zone.js';