// 2. FormBuilder
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
    selector: 'reactive-form',
    templateUrl: 'reactive.component.html'
})

export class ReactiveFormComponent implements OnInit {
    regForm: FormGroup;

    constructor(private formBuilder: FormBuilder) { }

    ngOnInit() {
        this.regForm = this.formBuilder.group({
            firstname: "",
            lastname: "",
            address: this.formBuilder.group({
                city: "",
                zip: 0
            })
        })
    }

    logForm() {
        console.log(this.regForm.value);
    }
}

// 1. FormGroup and FormControl
// import { Component, OnInit } from '@angular/core';
// import { FormGroup, FormControl } from '@angular/forms';

// @Component({
//     selector: 'reactive-form',
//     templateUrl: 'reactive.component.html'
// })

// export class ReactiveFormComponent implements OnInit {
//     regForm: FormGroup;

//     constructor() { }

//     ngOnInit() {
//         this.regForm = new FormGroup({
//             firstname: new FormControl(),
//             lastname: new FormControl(),
//             address: new FormGroup({
//                 city: new FormControl(),
//                 zip: new FormControl()
//             })
//         })
//     }

//     logForm(){
//         console.log(this.regForm.value);
//     }
// }