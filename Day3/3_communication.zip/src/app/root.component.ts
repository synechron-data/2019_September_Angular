import { Component, OnInit, AfterViewInit, ViewChild, QueryList, ViewChildren } from '@angular/core';
import { CounterComponent } from './counter/counter.component';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Communication</h1>
            </div>

            <ng-container *ngIf=flag>
                <counter></counter>
                <counter [interval]=5></counter>
            </ng-container>

            <ng-container *ngIf=flag>
                <counter #c1></counter>
                <counter #c2></counter>
                <br/>
                <div class="row">
                    <div class="col-md-2">
                        <button class="btn btn-warning btn-block" (click)="c1.reset()">Parent Reset</button>
                    </div>   
                    <div class="col-md-2">
                        <button class="btn btn-warning btn-block" (click)="p_reset(c1)">Parent Reset</button>
                    </div>    
                </div>
            </ng-container>

            <ng-container *ngIf=!flag>
                <h3 class="alert alert-danger" *ngIf=message>{{message}}</h3>
                <!-- <counter (onMax)="maxedOut($event)"></counter> -->
                <counter (onMax)="maxedOut($event)" [interval]=data></counter>
            </ng-container>
        </div>
    `
})

export class RootComponent implements OnInit, AfterViewInit {
    message: string;
    data: number;

    ngAfterViewInit(): void {
        // this.counter.interval = 100;
        // this.data = 100;
        // for (const counter of this.counters.toArray()) {
        //     counter.interval = 100;
        // }
    }

    // @ViewChild(CounterComponent)
    // @ViewChild("c2")
    // counter: CounterComponent;

    @ViewChildren(CounterComponent)
    counters: QueryList<CounterComponent>;

    constructor() {
    }

    p_reset(c: CounterComponent) {
        c.reset();
    }

    ngOnInit() {
        this.message = "";
        this.data = 1;
    }

    maxedOut(flag: boolean) {
        if (flag)
            this.message = "Max Click Reached, please reset to continue...";
        else
            this.message = "";
    }
}