import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'list',
    templateUrl: 'list.component.html'
})

export class ListComponent implements OnInit {
    personList: Array<string>;
    sPerson: string;

    constructor() {
        this.personList = ["Manish", "Abhijeet", "Abhishek", "Ramakant", "Subodh"];
    }

    ngOnInit() { }

    select(person: string, e: Event) {
        this.sPerson = person;
        e.preventDefault();
        console.log(e);
    }
}