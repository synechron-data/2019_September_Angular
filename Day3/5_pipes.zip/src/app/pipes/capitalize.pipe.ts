import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'capitalize',
    pure: true
})

export class CapitalizePipe implements PipeTransform {
    transform(value: string, ...args: any[]): string {
        if(!value)
            return value;

        return "Hello";
    }
}