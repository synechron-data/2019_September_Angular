import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription, Observable, interval } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
    selector: 'async-observable',
    template: `
        <h2 class="text-info">With Observable</h2>
        <h3>Result: {{observableData}}</h3>
        <h3>Promise Result: {{observableResult | async}}</h3>
    `
})

export class AsyncObservableComponent implements OnInit, OnDestroy {
    observableData: number;
    observableResult: Observable<number>;
    sub: Subscription;

    constructor() { }

    ngOnInit() {
        this.sub = this.getObservable().subscribe(d => this.observableData = d);
        this.observableResult = this.getObservable();
    }

    getObservable(): Observable<number> {
        return interval(2000).pipe(map(v => Math.random()));
    }

    ngOnDestroy(): void {
        this.sub.unsubscribe();
    }
}