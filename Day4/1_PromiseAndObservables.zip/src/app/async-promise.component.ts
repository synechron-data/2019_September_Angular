import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'async-promise',
    template: `
        <h2 class="text-info">With Promise</h2>
        <h3>Result: {{promiseData}}</h3>
        <h3>Promise Result: {{promiseResult | async}}</h3>
    `
})

export class AsyncPromiseComponent implements OnInit {
    promiseData: number;
    promiseResult: Promise<number>;

    constructor() { }

    ngOnInit() {
        this.getPromise().then(n => this.promiseData = n);
        this.promiseResult = this.getPromise();
    }

    getPromise(): Promise<number> {
        return new Promise((resolve, reject) => {
            setInterval(() => {
                resolve(Math.random());
            }, 2000);
        })
    }
}