import { Directive } from '@angular/core';

@Directive({ 
    selector: '[change-content]'
})
export class ChangeContentDirective {
    constructor() { }
}