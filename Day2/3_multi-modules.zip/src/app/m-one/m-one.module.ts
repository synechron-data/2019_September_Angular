import { NgModule } from '@angular/core';
import { COneComponent } from './cone.component';

@NgModule({
    exports: [COneComponent],
    declarations: [COneComponent]
})
export class MOneModule { }
