import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <c-one>Component will Load...</c-one>
            <c-two>Component will Load...</c-two>
            <hr />
            <c-one>Component will Load Again...</c-one>
            <c-two>Component will Load Again...</c-two>
        </div>
    `
})

export class RootComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}