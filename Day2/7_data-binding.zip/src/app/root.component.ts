import { Component, OnInit, AfterViewInit, NgZone } from '@angular/core';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Data Binding</h1>
            </div>

            <div [hidden]=flag>
                <assign-one></assign-one>
            </div>

            <div [hidden]=flag>
                <assign-two></assign-two>
            </div>

            <div [hidden]=!flag>
                <h2 class="text-success">Attribute Binding</h2>
                <img [src]=imageSource [height]=h [width]=w/>
                <table style="border: 1px solid black" [attr.height]=h [attr.width]=w>
                    <tr>
                        <th>Firstname</th>
                        <th>Lastname</th>
                        <th>Age</th>
                    </tr>
                    <tr>
                        <td>Jill</td>
                        <td>Smith</td>
                        <td>50</td>
                    </tr>
                    <tr>
                        <td>Eve</td>
                        <td>Jackson</td>
                        <td>94</td>
                    </tr>
                </table>
            </div>

            <div [hidden]=!flag>
                <h2 class="text-success">Two Way Binding</h2>
                <input type="text" bindon-ngModel=Data >
                <input type="text" [(ngModel)]=Data >
                <input type="text" [(ngModel)]=Data [ngModelOptions]="{updateOn:'blur'}">
                <h3>Message: {{Data}}</h3>
                <br/><br/>
                <input type="text" [(ngModel)]=name>
                <h3>Name is: {{name}}</h3>
                <br/><br/>
                <input type="text" [(ngModel)]=city (change)=doUpdate(city) (blur)=doBlur(city)>
                <input type="text" [(ngModel)]=city (input)=doUpdate(city)>
                <h3>Message: {{message}}</h3>
            </div>

            <div [hidden]=!flag>
                <h2 class="text-success">Event Binding</h2>
                <h3>Message: {{message}}</h3>
                <button class="btn btn-info" on-click="doChange()">Click</button>
                <button class="btn btn-info" (click)="doChange()">Click</button>
                <button class="btn btn-warning" id="btnJS">Click - JS</button>
            </div>

            <div [hidden]=!flag>
                <h2 class="text-success">Property Binding</h2>
                <h3>Message: {{message}}</h3>
                <h3 innerHTML={{message}}>Message: </h3>
                <h3>Message: <span innerText={{message}}></span></h3>
                <h3 bind-innerHTML=message>Message: </h3>
                <h3 [innerHTML]=message>Message: </h3>
                <hr/>
                <h3>Hiding: <span hidden={{flag}}>{{message}}</span></h3>
                <h3>Hiding: <span bind-hidden=flag>{{message}}</span></h3>
                <h3>Hiding: <span [hidden]=flag>{{message}}</span></h3>
            </div>
        </div>
    `
})

export class RootComponent implements OnInit, AfterViewInit {
    message: string;
    flag: boolean;
    imageSource: any;
    h: number;
    w: number;

    private _data: string;

    get Data() {
        return this._data;
    }

    set Data(value: string) {
        console.log("Set - ", value);
        this._data = value;
    }

    doUpdate(city: string) {
        console.log("Change");
        this.message = `Yo are from, ${city}`;
    }

    doBlur(city: string) {
        console.log("Blur");
        this.message = `Yo are from, ${city}`;
    }

    constructor(private zone: NgZone) {
        this.message = "Hello World!";
        this.flag = false;
        this.imageSource = require('../assets/image1.jpg');
        this.h = 300;
        this.w = 300;
    }

    ngAfterViewInit(): void {
        // document.getElementById("btnJS").addEventListener("click", () => {
        //     this.message = new Date().toTimeString()
        // });

        this.zone.runOutsideAngular(() => {
            document.getElementById("btnJS").addEventListener("click", () => {
                this.message = new Date().toTimeString();
                console.log(this.message);
            });
        })
    }

    doChange() {
        this.message = new Date().toTimeString()
    }

    ngOnInit() { }
}