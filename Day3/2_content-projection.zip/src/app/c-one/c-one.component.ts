import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'c-one',
    templateUrl: 'c-one.component.html'
})

export class COneComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}