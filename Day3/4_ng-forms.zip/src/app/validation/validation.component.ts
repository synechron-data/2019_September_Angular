import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

// function ageRangeValidator(control: AbstractControl): { [key: string]: boolean } | null {
//     if (!control.value) {
//         return null;
//     }

//     if (control.value !== undefined && (isNaN(control.value) || control.value < 18 || control.value > 60)) {
//         return { 'ageRange': true };
//     }

//     return null;
// }

function ageRangeValidator(min: number, max: number): ValidatorFn {
    return function (control: AbstractControl): { [key: string]: boolean } | null {
        if (!control.value) {
            return null;
        }

        if (control.value !== undefined && (isNaN(control.value) || control.value < min || control.value > max)) {
            return { 'ageRange': true };
        }

        return null;
    }
}

@Component({
    selector: 'validation-form',
    templateUrl: 'validation.component.html'
})

export class ValidationFormComponent implements OnInit {
    countries = [
        { 'id': "", 'name': 'Select Country' },
        { 'id': 1, 'name': 'India' },
        { 'id': 2, 'name': 'USA' },
        { 'id': 3, 'name': 'UK' }
    ];

    minAge = 18;
    maxAge = 60;

    regForm: FormGroup;

    constructor(private formBuilder: FormBuilder) { }

    get frm() { return this.regForm.controls; }
    get address() { return (<FormGroup>this.regForm.controls.address).controls; }

    ngOnInit() {
        this.regForm = this.formBuilder.group({
            firstname: ["", Validators.required],
            lastname: ["", Validators.compose([
                Validators.required,
                Validators.minLength(2),
                Validators.maxLength(6)
            ])],
            age: ["", [
                Validators.required,
                // ageRangeValidator
                ageRangeValidator(this.minAge, this.maxAge)
            ]],
            address: this.formBuilder.group({
                country: ["", Validators.required],
                city: ["", Validators.required],
                zip: [0, Validators.required]
            })
        })
    }

    logForm() {
        console.log(this.regForm.value);
    }
}